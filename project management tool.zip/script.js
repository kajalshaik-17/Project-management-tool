let tasks =
JSON.parse(localStorage.getItem("tasks")) || [];

function saveTasks(){
localStorage.setItem(
"tasks",
JSON.stringify(tasks)
);
}

function addTask(){

const taskName =
document.getElementById("taskName").value;

const priority =
document.getElementById("priority").value;

const dueDate =
document.getElementById("dueDate").value;

if(taskName===""){
alert("Enter task name");
return;
}

tasks.push({
taskName,
priority,
dueDate,
status:"To Do"
});

saveTasks();
renderTasks();

document.getElementById("taskName").value="";
document.getElementById("dueDate").value="";
}

function renderTasks(){

const taskList =
document.getElementById("taskList");

taskList.innerHTML="";

tasks.forEach((task,index)=>{

const card =
document.createElement("div");

card.className =
`task-card ${task.priority.toLowerCase()}`;

card.innerHTML=`

<div>
<h3>${task.taskName}</h3>

<p>Priority: ${task.priority}</p>

<p>Due Date: ${task.dueDate}</p>

<p>Status: ${task.status}</p>
</div>

<div>

<button onclick="changeStatus(${index})">
Update Status
</button>

<button onclick="deleteTask(${index})">
Delete
</button>

</div>
`;

taskList.appendChild(card);

});

}

function changeStatus(index){

if(tasks[index].status==="To Do"){
tasks[index].status="In Progress";
}
else if(tasks[index].status==="In Progress"){
tasks[index].status="Completed";
}
else{
tasks[index].status="To Do";
}

saveTasks();
renderTasks();
}

function deleteTask(index){

tasks.splice(index,1);

saveTasks();
renderTasks();
}

renderTasks();